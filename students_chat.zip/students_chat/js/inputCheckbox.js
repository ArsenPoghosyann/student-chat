$(() => {
    function inputCheckbox(btn, input) {
        btn.on("click", function() {
            if(input.attr("checked")) {
                input.removeAttr("checked");
            } else {
                input.attr("checked", "checked");
            }
        })
    }
    inputCheckbox($("#checkboxBtn"), $("#checkboxInput"));
})