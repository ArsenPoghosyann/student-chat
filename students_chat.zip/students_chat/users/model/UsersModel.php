<?php

class UsersModel {
    public $conn;
    public function __construct() {
        $this->conn = mysqli_connect("localhost", "root", "", "student_chat");
        if($this->conn->error) die($this->conn->error);
    }
    public function login($username, $password) {
        $query = $this->conn->prepare("SELECT * FROM students WHERE username = ? AND password = ?");
        $query->bind_param("ss", $username, $password);
        $query->execute();
        $result = $query->get_result();
        $row = $result->fetch_assoc();
        return $row;
    }
    public function username($username){
        $query = $this->conn->prepare("SELECT * FROM students WHERE username = ?");
        $query->bind_param("s", $username);
        $query->execute();
        $result = $query->get_result();
        $row = $result->fetch_assoc();
        return $row;
    } public function email($email) {
        $query = $this->conn->prepare("SELECT * FROM students WHERE email = ?");
        $query->bind_param("s", $email);
        $query->execute();
        $result = $query->get_result();
        $row = $result->fetch_assoc();
        return $row;
    }
    public function signUp($username, $password, $email, $full_name, $profile_picture, $created_at) {
        $query = $this->conn->prepare("INSERT INTO students
        (username, password, email, full_name, profile_picture, created_at)
        VALUES(?, ?, ?, ?, ?, ?)
        ");
        $query->bind_param("ssssss", $username, $password, $email, $full_name, $profile_picture, $created_at);
        $query->execute();
    }
}