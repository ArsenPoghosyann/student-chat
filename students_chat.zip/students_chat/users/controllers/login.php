<?php
session_start();
include_once("../model/UsersModel.php");
$username = $_POST["username"] ?? null;
$password = $_POST["password"] ?? null;
if($username && $password) {
    $usersModel = new UsersModel();
    $user = $usersModel->login($username, $password);
    if($user) {
        print_r($user);
        $_SESSION["user"] = $user;
        header("location: ../views/home.php");
        exit;
    }
} 
header("location: ../views/login.php");