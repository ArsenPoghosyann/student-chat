<?php

session_start();

include_once("../model/UsersModel.php");

$username = $_POST["username"] ?? null;
$password = $_POST["password"] ?? null;
$email = $_POST["email"] ?? null;
$full_name = $_POST["full_name"] ?? null;
$profile_picture = $_POST["profile_picture"] ?? "";

if(!$username) {
    $_SESSION["error"] = "The username is required";
    header("location: ../views/signUp.php");
    exit;
} else if(!$password) {
    $_SESSION["error"] = "The password is required";
    header("location: ../views/signUp.php");
    exit;
} else if(!$email) {
    $_SESSION["error"] = "The email is required";
    header("location: ../views/signUp.php");
    exit;
} else if(!$full_name) {
    $_SESSION["error"] = "The full name is required";
    header("location: ../views/signUp.php");
    exit;
} else {
    $usersModel = new UsersModel();
    $usernameRow = $usersModel->username($username);
    $emailRow = $usersModel->email($email);
    if(!$usernameRow) {
        if(!$emailRow) {
            $usersModel->signUp($username, $password, $email, $full_name, $profile_picture, date("Y-m-d"));
            $_SESSION["username"] = $username;
            $_SESSION["password"] = $password;
            $_SESSION["email"] = $email;
            $_SESSION["full_name"] = $full_name;
            $_SESSION["profile_picture"] = $profile_picture;
            header("location: ../views/home.php");
        } else {
            $_SESSION["error"] = "The email is exist";
            header("location: ../views/signUp.php");
        }
    } else {
        $_SESSION["error"] = "The username is exist";
        header("location: ../views/signUp.php");
    }
}