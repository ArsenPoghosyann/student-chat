<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../src/output.css">
</head>
<body class="h-dvh flex justify-center items-center font-InstagramSans">
    <div class="w-[320px] h-[600px] flex flex-col justify-between">
        <div class="w-full h-[490px] border border-black flex flex-col items-center">
            <div class="w-full h-[100px] flex justify-center items-center">
                <img class="w-[50px] h-[50px]" src="../../public/assets/images/logo.png">
                <h1 class="text-2xl">Students chat</h1>
            </div>
            <form action="../controllers/signUp.php" method="post" class="w-4/5 h-[390px] flex flex-col justify-around">
                <input class="w-full h-10 border border-black rounded-[10px] pl-2.5" type="text" placeholder="username" name="username">
                <input class="w-full h-10 border border-black rounded-[10px] pl-2.5" type="password" placeholder="password" name="password">
                <input class="w-full h-10 border border-black rounded-[10px] pl-2.5" type="text" placeholder="email" name="email">
                <input class="w-full h-10 border border-black rounded-[10px] pl-2.5" type="text" placeholder="full name" name="full_name">
                <input class="w-full h-10 border border-black rounded-[10px] pl-2.5" type="file" placeholder="profile picture" nmae="profile_picture">
                <button class="w-full h-10 hover:bg-crayolas-blue-violet-transparent text-crayolas-blue-violet cursor-pointer rounded-[10px]">Sign up</button>
            </form>
        </div>
        <div class="w-full h-[100px] border border-black flex justify-center items-center">
            <span>Have an account?</span>
            <a href="./login.php" class="text-crayolas-blue-violet">Log in</a>
        </div>
    </div>
</body>
</html>