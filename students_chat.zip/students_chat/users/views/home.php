<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../src/output.css">
</head>
<body class="h-dvh bg-[url('../../public/assets/images/lightBackground.png')] bg-cover bg-center">
    <?php 
    include_once("../../includes/contacts.php");    
    ?>
</body>
</html>