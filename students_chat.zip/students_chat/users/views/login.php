<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../src/output.css">
    <script src="../../js/jquery.js"></script>
    <script src="../../js/inputCheckbox.js"></script>
</head>
<body class="h-dvh flex justify-center items-center font-InstagramSans">
    <div class="w-[320px] h-[500px] flex flex-col justify-between">
        <div class="w-full h-[390px] border border-black flex flex-col items-center">
            <div class="w-full h-[100px] flex justify-center items-center">
                <img class="w-[50px] h-[50px]" src="../../public/assets/images/logo.png">
                <h1 class="text-2xl">Students chat</h1>
            </div>
            <form action="../controllers/login.php" method="post" class="w-4/5 h-60 flex flex-col justify-around">
                <input type="text" class="w-full h-10 border border-black rounded-[10px] pl-2.5" name="username">    
                <input type="password" class="w-full h-10 border border-black rounded-[10px] pl-2.5" name="password">
                <button class="w-full h-10 hover:bg-light-gray transition duration-500 flex items-center pl-2.5 rounded-[10px] cursor-pointer" type="button" id="checkboxBtn">
                    <input class="w-5 h-5" type="checkbox" id="checkboxInput">
                    <span class="ml-2.5 text-[17px]">Keep me signed in</span>
                </button>
                <button class="w-full h-10 hover:bg-crayolas-blue-violet-transparent text-crayolas-blue-violet cursor-pointer rounded-[10px]">Log in</button>
            </form>
            <a href="">Forgot password?</a>
        </div>
        <div class="w-full h-[100px] border border-black flex justify-center items-center">
            <span>Don't have an account?</span>
            <a href="./signUp.php" class="text-crayolas-blue-violet">Sign up</a>
        </div>
    </div>
</body>
</html>